﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai11_THO
    {
        public static void Run()
        {
            Console.Write("Nhap so phan tu n: ");
            int n = Convert.ToInt32(Console.ReadLine());
            if (n < 0)
            {
                Console.WriteLine("n khong hop le!");
                return;
            }

            int[] arr = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap arr[{i}] (mang tang dan): ");
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            // Kiem tra mang co tang dan khong (neu chua, se sap xep lai de an toan)
            if (!IsNonDecreasing(arr))
            {
                Console.WriteLine("Canh bao: Mang chua tang dan. Se tu dong sap xep tang dan truoc khi chen.");
                Array.Sort(arr);
            }

            Console.Write("Nhap so nguyen x can chen: ");
            int x = Convert.ToInt32(Console.ReadLine());

            // Tim vi tri chen bang tim kiem nhi phan (vi tri dau tien >= x)
            int pos = LowerBound(arr, x);

            // Tao mang moi co kich thuoc n+1 va chen x
            int[] result = new int[n + 1];
            for (int i = 0; i < pos; i++) result[i] = arr[i];
            result[pos] = x;
            for (int i = pos; i < n; i++) result[i + 1] = arr[i];

            // In ket qua
            Console.WriteLine("Mang ban dau (tang dan):");
            PrintArray(arr);

            Console.WriteLine($"Chen {x} vao vi tri {pos}:");
            PrintArray(result);
        }

        // Kiem tra mang khong giam (tang dan cho phep phan tu bang nhau)
        private static bool IsNonDecreasing(int[] a)
        {
            for (int i = 1; i < a.Length; i++)
                if (a[i] < a[i - 1]) return false;
            return true;
        }

        // LowerBound: tra ve chi so phan tu dau tien >= x (neu tat ca < x thi tra ve a.Length)
        private static int LowerBound(int[] a, int x)
        {
            int l = 0, r = a.Length; // [l, r)
            while (l < r)
            {
                int m = l + (r - l) / 2;
                if (a[m] >= x) r = m;
                else l = m + 1;
            }
            return l;
        }

        private static void PrintArray(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
                Console.Write(a[i] + " ");
            Console.WriteLine();
        }
    }
}
