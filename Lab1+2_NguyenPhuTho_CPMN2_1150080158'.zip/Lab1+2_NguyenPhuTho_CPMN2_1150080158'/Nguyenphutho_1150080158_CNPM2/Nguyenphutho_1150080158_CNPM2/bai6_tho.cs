﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai6_THO
    {
        public static void Run()
        {
            // Nhap du lieu
            Console.Write("Nhap chieu dai a (>0): ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap chieu rong b (>0): ");
            double b = Convert.ToDouble(Console.ReadLine());

            // Kiem tra hop le
            if (a <= 0 || b <= 0)
            {
                Console.WriteLine("Chieu dai va chieu rong phai la so thuc duong!");
                return;
            }

            // Tinh chu vi va dien tich
            double P = 2 * (a + b);
            double S = a * b;

            // Hien thi ket qua
            Console.WriteLine("Chu vi hinh chu nhat la: " + P);
            Console.WriteLine("Dien tich hinh chu nhat la: " + S);
        }
    }
}
