﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai9_THO
    {
        public static void Run()
        {
            Console.Write("Nhap so phan tu cua mang n: ");
            int n = Convert.ToInt32(Console.ReadLine());

            if (n <= 0)
            {
                Console.WriteLine("So phan tu phai lon hon 0!");
                return;
            }

            int[] arr = new int[n];

            // Nhap mang
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Nhap phan tu arr[{i}]: ");
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            // Tinh tong
            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                sum += arr[i];
            }

            // Hien thi ket qua
            Console.WriteLine("Tong cac phan tu trong mang la: " + sum);
        }
    }
}
