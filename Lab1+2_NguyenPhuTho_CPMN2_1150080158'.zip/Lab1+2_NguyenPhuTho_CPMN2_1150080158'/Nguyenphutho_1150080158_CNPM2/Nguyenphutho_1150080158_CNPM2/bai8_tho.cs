﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai8_THO
    {
        public static void Run()
        {
            // Nhap he so
            Console.Write("Nhap a: ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap c: ");
            double c = Convert.ToDouble(Console.ReadLine());

            // Xu ly truong hop
            if (a == 0)
            {
                // Phuong trinh bac 1: bx + c = 0
                if (b == 0)
                {
                    if (c == 0)
                        Console.WriteLine("Phuong trinh co vo so nghiem.");
                    else
                        Console.WriteLine("Phuong trinh vo nghiem.");
                }
                else
                {
                    double x = -c / b;
                    Console.WriteLine("Phuong trinh bac nhat, co nghiem x = " + x);
                }
            }
            else
            {
                // Phuong trinh bac 2
                double delta = b * b - 4 * a * c;

                if (delta < 0)
                {
                    Console.WriteLine("Phuong trinh vo nghiem.");
                }
                else if (delta == 0)
                {
                    double x = -b / (2 * a);
                    Console.WriteLine("Phuong trinh co nghiem kep: x = " + x);
                }
                else
                {
                    double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                    double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                    Console.WriteLine("Phuong trinh co 2 nghiem phan biet:");
                    Console.WriteLine("x1 = " + x1);
                    Console.WriteLine("x2 = " + x2);
                }
            }
        }
    }
}
