﻿using System;
using System.IO;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai10_THO
    {
        public static void Run()
        {
            int[] arr;

            string filePath = "input_array.txt";
            if (File.Exists(filePath))
            {
                // Doc du lieu tu file
                string content = File.ReadAllText(filePath);
                string[] parts = content.Split(new char[] { ' ', '\n', '\r', '\t' },
                                               StringSplitOptions.RemoveEmptyEntries);

                arr = new int[parts.Length];
                for (int i = 0; i < parts.Length; i++)
                {
                    arr[i] = int.Parse(parts[i]);
                }

                Console.WriteLine("Doc mang tu file input_array.txt thanh cong!");
            }
            else
            {
                // Nguoi dung tu nhap
                Console.Write("Nhap so phan tu cua mang n: ");
                int n = Convert.ToInt32(Console.ReadLine());

                arr = new int[n];
                for (int i = 0; i < n; i++)
                {
                    Console.Write($"Nhap phan tu arr[{i}]: ");
                    arr[i] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Mang ban dau:");
            PrintArray(arr);

            // Selection Sort
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[j] < arr[minIndex])
                    {
                        minIndex = j;
                    }
                }

                // Doi cho
                if (minIndex != i)
                {
                    int temp = arr[i];
                    arr[i] = arr[minIndex];
                    arr[minIndex] = temp;
                }
            }

            Console.WriteLine("Mang sau khi sap xep tang dan:");
            PrintArray(arr);
        }

        private static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
