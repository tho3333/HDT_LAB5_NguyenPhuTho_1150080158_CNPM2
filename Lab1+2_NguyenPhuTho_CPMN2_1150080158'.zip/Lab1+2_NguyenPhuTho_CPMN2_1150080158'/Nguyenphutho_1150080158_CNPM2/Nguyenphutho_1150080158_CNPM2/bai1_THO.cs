﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai1_THO
    {
        public static void Run()
        {
            Console.Write("Nhap chieu dai a: ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap chieu rong b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            if (a <= 0 || b <= 0)
            {
                Console.WriteLine("Chieu dai va chieu rong phai la so duong!");
                return;
            }

            double P = 2 * (a + b);
            double S = a * b;

            Console.WriteLine("Chu vi la: " + P);
            Console.WriteLine("Dien tich la: " + S);
        }
    }
}
