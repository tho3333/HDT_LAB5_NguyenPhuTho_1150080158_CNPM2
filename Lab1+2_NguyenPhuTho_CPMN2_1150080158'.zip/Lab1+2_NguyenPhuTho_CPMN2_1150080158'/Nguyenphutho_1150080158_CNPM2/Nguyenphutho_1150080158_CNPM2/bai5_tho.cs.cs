﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai5_THO
    {
        public static void Run()
        {
            // Nhap du lieu
            Console.Write("Nhap vao so nguyen n: ");
            int n = Convert.ToInt32(Console.ReadLine());

            // a) Kiem tra chan/le
            if (n % 2 == 0)
            {
                Console.WriteLine("n la so chan");
            }
            else
            {
                Console.WriteLine("n la so le");
            }

            // b) Kiem tra am/khong am
            if (n < 0)
            {
                Console.WriteLine("n la so am");
            }
            else
            {
                Console.WriteLine("n la so khong am");
            }
        }
    }
}
