﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai3_THO
    {
        public static void Run()
        {
            // Nhap du lieu
            Console.Write("Nhap vao so nguyen a: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhap vao so nguyen b: ");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhap vao so nguyen c: ");
            int c = Convert.ToInt32(Console.ReadLine());

            // Tim so lon nhat trong 3 so
            int max = a; // giả sử ban đầu max = a

            if (b > max)
            {
                max = b;
            }
            if (c > max)
            {
                max = c;
            }

            // Hien thi ket qua
            Console.WriteLine("So lon nhat trong 3 so la: " + max);
        }
    }
}
