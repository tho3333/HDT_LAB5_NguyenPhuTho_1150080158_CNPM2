﻿using System;
using System.Text;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // Gọi bài 
            //Bai1_THO.Run();
            // Gọi bài 2
            //Bai2_THO.Run();
            //Bai3_THO.Run();
            //Bai4_THO.Run();
            //Bai5_THO.Run();
            //Bai6_THO.Run();
            //Bai7_THO.Run();
            //Bai8_THO.Run();
           // Bai9_THO.Run();
            //Bai10_THO.Run();
            Bai11_THO.Run();
        }
    }
}
