﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai7_THO
    {
        public static void Run()
        {
            // Nhap do dai 3 canh
            Console.Write("Nhap do dai canh a: ");
            double a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap do dai canh b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Nhap do dai canh c: ");
            double c = Convert.ToDouble(Console.ReadLine());

            // Kiem tra hop le
            if (a <= 0 || b <= 0 || c <= 0)
            {
                Console.WriteLine("Do dai cac canh phai la so thuc duong!");
                return;
            }

            // Kiem tra dieu kien tao thanh tam giac
            if (a + b > c && a + c > b && b + c > a)
            {
                double P = a + b + c;           // Chu vi
                double p = P / 2;              // Nua chu vi
                double S = Math.Sqrt(p * (p - a) * (p - b) * (p - c)); // Cong thuc Heron

                Console.WriteLine("Ba doan thang lap thanh mot tam giac.");
                Console.WriteLine("Chu vi tam giac: " + P);
                Console.WriteLine("Dien tich tam giac: " + S);
            }
            else
            {
                Console.WriteLine("Ba doan thang khong the lap thanh mot tam giac.");
            }
        }
    }
}
