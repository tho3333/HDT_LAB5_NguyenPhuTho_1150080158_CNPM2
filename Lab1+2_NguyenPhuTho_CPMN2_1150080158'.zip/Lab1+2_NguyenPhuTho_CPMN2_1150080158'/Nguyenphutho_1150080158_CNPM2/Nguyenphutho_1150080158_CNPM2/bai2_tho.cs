﻿using System;

namespace Nguyenphutho_1150080158_CNPM2
{
    internal static class Bai2_THO
    {
        public static void Run()
        {
            // Nhap du lieu
            Console.Write("Nhap vao so nguyen a: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhap vao so nguyen b: ");
            int b = Convert.ToInt32(Console.ReadLine());

            // Tim so lon hon
            int max = 0;
            if (a > b)
            {
                max = a;
            }
            if (b > a)
            {
                max = b;
            }

            // Hien thi ket qua
            Console.WriteLine("So lon hon trong 2 so la: " + max);
        }
    }
}
