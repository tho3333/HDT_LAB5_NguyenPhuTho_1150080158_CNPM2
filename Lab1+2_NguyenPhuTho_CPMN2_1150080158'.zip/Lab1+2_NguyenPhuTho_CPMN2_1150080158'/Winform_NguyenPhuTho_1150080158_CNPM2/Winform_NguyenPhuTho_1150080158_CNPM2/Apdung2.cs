﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Nguyenphutho_1150080158_CNPM2
{
    public class ApDung2 : Form
    {
        private TextBox txtPassword;
        private Button[] numButtons;
        private Button btnDangKy, btnDangNhap, btnClear;
        private RichTextBox rtbLog;

        private string currentPassword = null; // mật mã hiện tại (do user đăng ký)

        public ApDung2()
        {
            InitUI();
        }

        private void InitUI()
        {
            Text = "Security Panel - ApDung2";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(360, 480);
            Font = new Font("Segoe UI", 10);

            // TextBox mật khẩu (ẩn ký tự nhập)
            txtPassword = new TextBox
            {
                Location = new Point(20, 20),
                Width = 300,
                UseSystemPasswordChar = true,
                ReadOnly = true
            };

            // Bàn phím số
            numButtons = new Button[10];
            int startX = 20, startY = 60;
            int btnSize = 60, gap = 10;
            for (int i = 1; i <= 9; i++)
            {
                numButtons[i] = new Button
                {
                    Text = i.ToString(),
                    Size = new Size(btnSize, btnSize),
                    Location = new Point(startX + ((i - 1) % 3) * (btnSize + gap),
                                         startY + ((i - 1) / 3) * (btnSize + gap))
                };
                numButtons[i].Click += NumButton_Click;
                Controls.Add(numButtons[i]);
            }

            // Nút 0
            numButtons[0] = new Button
            {
                Text = "0",
                Size = new Size(btnSize, btnSize),
                Location = new Point(startX + (btnSize + gap),
                                     startY + 3 * (btnSize + gap))
            };
            numButtons[0].Click += NumButton_Click;
            Controls.Add(numButtons[0]);

            // Nút Đăng ký
            btnDangKy = new Button
            {
                Text = "Dang ky",
                Size = new Size(100, 40),
                Location = new Point(20, startY + 4 * (btnSize + gap))
            };
            btnDangKy.Click += BtnDangKy_Click;

            // Nút Đăng nhập
            btnDangNhap = new Button
            {
                Text = "Dang nhap",
                Size = new Size(100, 40),
                Location = new Point(130, startY + 4 * (btnSize + gap))
            };
            btnDangNhap.Click += BtnDangNhap_Click;

            // Nút Clear
            btnClear = new Button
            {
                Text = "Clear",
                Size = new Size(100, 40),
                Location = new Point(240, startY + 4 * (btnSize + gap))
            };
            btnClear.Click += (s, e) => txtPassword.Clear();

            // RichTextBox log
            rtbLog = new RichTextBox
            {
                Location = new Point(20, startY + 5 * (btnSize + gap)),
                Size = new Size(300, 140),
                ReadOnly = true
            };

            Controls.AddRange(new Control[] { txtPassword, btnDangKy, btnDangNhap, btnClear, rtbLog });
        }

        private void NumButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null) txtPassword.Text += btn.Text;
        }

        private void BtnDangKy_Click(object sender, EventArgs e)
        {
            string input = txtPassword.Text.Trim();
            if (string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Vui long nhap mat khau truoc khi Dang ky!");
                return;
            }

            currentPassword = input;
            txtPassword.Clear();
            rtbLog.AppendText($"{DateTime.Now}: Da dang ky mat khau moi.\n");
        }

        private void BtnDangNhap_Click(object sender, EventArgs e)
        {
            string input = txtPassword.Text.Trim();
            txtPassword.Clear();

            if (string.IsNullOrEmpty(currentPassword))
            {
                MessageBox.Show("Chua co mat khau nao duoc dang ky!");
                return;
            }

            if (input == currentPassword)
            {
                rtbLog.AppendText($"{DateTime.Now}: Dang nhap thanh cong - Chap nhan.\n");
            }
            else
            {
                rtbLog.AppendText($"{DateTime.Now}: Sai mat khau - Tu choi.\n");
            }
        }
    }
}
