﻿using System;
using System.Windows.Forms;
using Nguyenphutho_1150080158_CNPM2;

namespace Winform_NguyenPhuTho_1150080158_CNPM2
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());
            // Application.Run(new ApDung1());
            //Application.Run(new ApDung2());
            //Application.Run(new ThucHanh2());
            //Application.Run(new Apdung3());
            //Application.Run(new ThucHanh3());
            Application.Run(new ThucHanh4());


        }
    }
}
