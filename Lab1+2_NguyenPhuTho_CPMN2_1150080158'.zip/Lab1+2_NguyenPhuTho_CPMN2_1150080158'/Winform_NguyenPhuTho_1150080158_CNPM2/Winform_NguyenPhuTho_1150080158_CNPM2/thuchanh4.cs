﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Nguyenphutho_1150080158_CNPM2
{
    public class ThucHanh4 : Form
    {
        private ListBox lstMatHang, lstLuaChon;
        private Button btnChuyen1, btnChuyenAll, btnTra1, btnTraAll;
        private Label lblMH, lblLC;

        public ThucHanh4()
        {
            InitUI();
            LoadData();
        }

        private void InitUI()
        {
            Text = "Quản lý mặt hàng - 2025";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(800, 450);
            BackColor = Color.WhiteSmoke;
            Font = new Font("Segoe UI", 11);

            lblMH = new Label
            {
                Text = "Danh sách các mặt hàng",
                Location = new Point(100, 30),
                AutoSize = true,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.DarkBlue
            };

            lblLC = new Label
            {
                Text = "Các mặt hàng lựa chọn",
                Location = new Point(500, 30),
                AutoSize = true,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.DarkGreen
            };

            lstMatHang = new ListBox
            {
                Location = new Point(60, 70),
                Size = new Size(250, 280),
                Font = new Font("Segoe UI", 11),
                SelectionMode = SelectionMode.MultiExtended
            };

            lstLuaChon = new ListBox
            {
                Location = new Point(480, 70),
                Size = new Size(250, 280),
                Font = new Font("Segoe UI", 11),
                SelectionMode = SelectionMode.MultiExtended
            };

            // Các nút điều khiển
            btnChuyen1 = new Button
            {
                Text = ">",
                Location = new Point(350, 120),
                Size = new Size(80, 40),
                BackColor = Color.LightSkyBlue,
                FlatStyle = FlatStyle.Flat
            };
            btnChuyen1.Click += BtnChuyen1_Click;

            btnChuyenAll = new Button
            {
                Text = ">>",
                Location = new Point(350, 170),
                Size = new Size(80, 40),
                BackColor = Color.DeepSkyBlue,
                FlatStyle = FlatStyle.Flat
            };
            btnChuyenAll.Click += BtnChuyenAll_Click;

            btnTra1 = new Button
            {
                Text = "<",
                Location = new Point(350, 220),
                Size = new Size(80, 40),
                BackColor = Color.LightCoral,
                FlatStyle = FlatStyle.Flat
            };
            btnTra1.Click += BtnTra1_Click;

            btnTraAll = new Button
            {
                Text = "<<",
                Location = new Point(350, 270),
                Size = new Size(80, 40),
                BackColor = Color.IndianRed,
                FlatStyle = FlatStyle.Flat
            };
            btnTraAll.Click += BtnTraAll_Click;

            Controls.AddRange(new Control[]
            {
                lblMH, lblLC, lstMatHang, lstLuaChon,
                btnChuyen1, btnChuyenAll, btnTra1, btnTraAll
            });
        }

        private void LoadData()
        {
            string[] hang = { "Áo sơ mi", "Quần jean", "Giày sneaker", "Laptop", "Điện thoại", "Tai nghe", "Bàn phím cơ", "Chuột gaming", "Túi xách", "Đồng hồ" };
            lstMatHang.Items.AddRange(hang);
        }

        private void BtnChuyen1_Click(object sender, EventArgs e)
        {
            var selected = lstMatHang.SelectedItems.Cast<object>().ToList();
            foreach (var item in selected)
            {
                lstLuaChon.Items.Add(item);
            }
            foreach (var item in selected)
            {
                lstMatHang.Items.Remove(item);
            }
        }

        private void BtnChuyenAll_Click(object sender, EventArgs e)
        {
            lstLuaChon.Items.AddRange(lstMatHang.Items);
            lstMatHang.Items.Clear();
        }

        private void BtnTra1_Click(object sender, EventArgs e)
        {
            var selected = lstLuaChon.SelectedItems.Cast<object>().ToList();
            foreach (var item in selected)
            {
                lstMatHang.Items.Add(item);
            }
            foreach (var item in selected)
            {
                lstLuaChon.Items.Remove(item);
            }
        }
        private void BtnTraAll_Click(object sender, EventArgs e)
        {
            lstMatHang.Items.AddRange(lstLuaChon.Items);
            lstLuaChon.Items.Clear();
        }
    }
}
