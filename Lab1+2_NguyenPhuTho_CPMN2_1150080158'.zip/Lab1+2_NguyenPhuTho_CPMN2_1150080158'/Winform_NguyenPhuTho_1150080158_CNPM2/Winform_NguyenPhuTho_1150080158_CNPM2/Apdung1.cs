﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Nguyenphutho_1150080158_CNPM2
{
    public class ApDung1 : Form
    {
        // Controls
        private TextBox txtA, txtB, txtKetQua;
        private RadioButton radUSCLN, radBCNN;
        private Button btnTim, btnThoat;
        private Label lblA, lblB, lblKQ;

        public ApDung1()
        {
            InitUI(); // không dùng InitializeComponent của Designer
        }

        // ====== Logic UCLN/BCNN ======
        private int GCD(int x, int y)
        {
            x = Math.Abs(x);
            y = Math.Abs(y);
            while (y != 0)
            {
                int t = y;
                y = x % y;
                x = t;
            }
            return x;
        }

        private int LCM(int x, int y)
        {
            if (x == 0 || y == 0) return 0;
            return Math.Abs(x * y) / GCD(x, y);
        }

        // ====== Event handlers (KHÔNG dùng object?) ======
        private void BtnTim_Click(object sender, EventArgs e)
        {
            int a, b;
            if (!int.TryParse(txtA.Text, out a))
            {
                MessageBox.Show("Vui long nhap so nguyen hop le cho a!");
                return;
            }
            if (!int.TryParse(txtB.Text, out b))
            {
                MessageBox.Show("Vui long nhap so nguyen hop le cho b!");
                return;
            }

            if (radUSCLN.Checked)
            {
                txtKetQua.Text = "UCLN = " + GCD(a, b);
            }
            else if (radBCNN.Checked)
            {
                txtKetQua.Text = "BCNN = " + LCM(a, b);
            }
            else
            {
                MessageBox.Show("Hay chon 'Tim UCLN' hoac 'Tim BCNN' truoc khi bam Tim!");
            }
        }

        private void BtnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        // ====== UI builder ======
        private void InitUI()
        {
            Text = "Ap dung 1 - UCLN/BCNN";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(420, 230);
            Font = new Font("Segoe UI", 10);

            lblA = new Label { Text = "Nhap a:", AutoSize = true, Location = new Point(20, 20) };
            txtA = new TextBox { Name = "txtA", Location = new Point(120, 16), Width = 260 };

            lblB = new Label { Text = "Nhap b:", AutoSize = true, Location = new Point(20, 60) };
            txtB = new TextBox { Name = "txtB", Location = new Point(120, 56), Width = 260 };

            radUSCLN = new RadioButton { Name = "radUSCLN", Text = "Tim UCLN", Location = new Point(120, 92), AutoSize = true };
            radBCNN = new RadioButton { Name = "radBCNN", Text = "Tim BCNN", Location = new Point(230, 92), AutoSize = true };

            lblKQ = new Label { Text = "Ket qua:", AutoSize = true, Location = new Point(20, 130) };
            txtKetQua = new TextBox { Name = "txtKetQua", Location = new Point(120, 126), Width = 260, ReadOnly = true };

            btnTim = new Button { Text = "Tim", Location = new Point(120, 165), Size = new Size(80, 32) };
            btnThoat = new Button { Text = "Thoat", Location = new Point(300, 165), Size = new Size(80, 32) };

            btnTim.Click += BtnTim_Click;
            btnThoat.Click += BtnThoat_Click;

            Controls.AddRange(new Control[]
            {
                lblA, txtA,
                lblB, txtB,
                radUSCLN, radBCNN,
                lblKQ, txtKetQua,
                btnTim, btnThoat
            });
        }
    }
}
