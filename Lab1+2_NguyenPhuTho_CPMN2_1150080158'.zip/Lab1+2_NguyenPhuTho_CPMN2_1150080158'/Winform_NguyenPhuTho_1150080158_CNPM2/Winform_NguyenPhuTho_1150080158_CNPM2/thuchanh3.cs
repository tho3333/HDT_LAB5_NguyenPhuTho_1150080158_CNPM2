﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Nguyenphutho_1150080158_CNPM2
{
    public class ThucHanh3 : Form
    {
        private TextBox txtNhap;
        private Button btnNhap, btnTang2, btnChonChanDau, btnChonLeCuoi,
                       btnXoaChon, btnXoaDau, btnXoaCuoi;
        private ListBox lstDaySo;
        private Label lblKetQua;

        public ThucHanh3()
        {
            InitUI();
        }

        private void InitUI()
        {
            Text = "Ứng dụng xử lý dãy số";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(600, 420);
            BackColor = Color.WhiteSmoke;
            Font = new Font("Segoe UI", 10);

            // Tiêu đề
            Label lblTitle = new Label
            {
                Text = "ỨNG DỤNG XỬ LÝ DÃY SỐ",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.DarkCyan,
                AutoSize = true,
                Location = new Point(170, 20)
            };

            // Nhập số
            Label lblNhap = new Label { Text = "Nhập số nguyên:", Location = new Point(30, 70), AutoSize = true };
            txtNhap = new TextBox { Location = new Point(150, 66), Width = 150 };
            txtNhap.KeyPress += TxtNhap_KeyPress;
            txtNhap.KeyDown += TxtNhap_KeyDown;

            btnNhap = new Button
            {
                Text = "Nhập số",
                Location = new Point(320, 64),
                Size = new Size(100, 30),
                BackColor = Color.LightGreen,
                FlatStyle = FlatStyle.Popup
            };
            btnNhap.Click += BtnNhap_Click;

            // ListBox
            lstDaySo = new ListBox
            {
                Location = new Point(30, 110),
                Size = new Size(200, 250),
                Font = new Font("Consolas", 11)
            };

            // Chức năng
            Label lblCN = new Label { Text = "Chức năng:", Location = new Point(270, 110), AutoSize = true, Font = new Font("Segoe UI", 11, FontStyle.Bold) };

            btnTang2 = new Button { Text = "Tăng mỗi phần tử lên 2", Location = new Point(270, 140), Size = new Size(250, 30) };
            btnTang2.Click += BtnTang2_Click;

            btnChonChanDau = new Button { Text = "Chọn số chẵn đầu", Location = new Point(270, 180), Size = new Size(250, 30) };
            btnChonChanDau.Click += BtnChonChanDau_Click;

            btnChonLeCuoi = new Button { Text = "Chọn số lẻ cuối", Location = new Point(270, 220), Size = new Size(250, 30) };
            btnChonLeCuoi.Click += BtnChonLeCuoi_Click;

            btnXoaChon = new Button { Text = "Xóa phần tử đang chọn", Location = new Point(270, 260), Size = new Size(250, 30) };
            btnXoaChon.Click += BtnXoaChon_Click;

            btnXoaDau = new Button { Text = "Xóa phần tử đầu", Location = new Point(270, 300), Size = new Size(250, 30) };
            btnXoaDau.Click += (s, e) => { if (lstDaySo.Items.Count > 0) lstDaySo.Items.RemoveAt(0); };

            btnXoaCuoi = new Button { Text = "Xóa phần tử cuối", Location = new Point(270, 340), Size = new Size(250, 30) };
            btnXoaCuoi.Click += (s, e) => { if (lstDaySo.Items.Count > 0) lstDaySo.Items.RemoveAt(lstDaySo.Items.Count - 1); };

            lblKetQua = new Label { Text = "Kết quả:", Location = new Point(30, 370), AutoSize = true, ForeColor = Color.DarkRed, Font = new Font("Segoe UI", 11, FontStyle.Bold) };

            Controls.AddRange(new Control[]
            {
                lblTitle, lblNhap, txtNhap, btnNhap,
                lstDaySo, lblCN, btnTang2, btnChonChanDau,
                btnChonLeCuoi, btnXoaChon, btnXoaDau, btnXoaCuoi,
                lblKetQua
            });
        }

        private void TxtNhap_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '-') e.Handled = true;
        }

        private void TxtNhap_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                AddSo();
                e.SuppressKeyPress = true;
            }
        }

        private void BtnNhap_Click(object sender, EventArgs e) => AddSo();

        private void AddSo()
        {
            if (int.TryParse(txtNhap.Text, out int so))
            {
                lstDaySo.Items.Add(so);
                txtNhap.Clear();
                txtNhap.Focus();
            }
            else
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ!");
            }
        }

        private void BtnTang2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstDaySo.Items.Count; i++)
            {
                int val = (int)lstDaySo.Items[i];
                lstDaySo.Items[i] = val + 2;
            }
        }

        private void BtnChonChanDau_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstDaySo.Items.Count; i++)
            {
                if ((int)lstDaySo.Items[i] % 2 == 0)
                {
                    lstDaySo.SelectedIndex = i;
                    lblKetQua.Text = $"Số chẵn đầu tiên: {lstDaySo.Items[i]}";
                    return;
                }
            }
            lblKetQua.Text = "Không có số chẵn nào.";
        }

        private void BtnChonLeCuoi_Click(object sender, EventArgs e)
        {
            for (int i = lstDaySo.Items.Count - 1; i >= 0; i--)
            {
                if ((int)lstDaySo.Items[i] % 2 != 0)
                {
                    lstDaySo.SelectedIndex = i;
                    lblKetQua.Text = $"Số lẻ cuối cùng: {lstDaySo.Items[i]}";
                    return;
                }
            }
            lblKetQua.Text = "Không có số lẻ nào.";
        }

        private void BtnXoaChon_Click(object sender, EventArgs e)
        {
            if (lstDaySo.SelectedIndex >= 0)
            {
                lstDaySo.Items.RemoveAt(lstDaySo.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Hãy chọn phần tử để xóa!");
            }
        }
    }
}
