﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Nguyenphutho_1150080158_CNPM2
{
    public class Apdung3 : Form
    {
        private TextBox txtUsername, txtPassword;
        private Button btnLogin, btnThoat;

        public Apdung3()
        {
            InitUI();
        }

        private void InitUI()
        {
            Text = "Đăng nhập hệ thống";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(400, 250);
            BackColor = Color.WhiteSmoke;
            Font = new Font("Segoe UI", 10);

            // Tiêu đề
            Label lblTitle = new Label
            {
                Text = "FORM ĐĂNG NHẬP",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                AutoSize = true,
                Location = new Point(110, 20)
            };

            // Username
            Label lblUser = new Label { Text = "Username:", Location = new Point(40, 70), AutoSize = true };
            txtUsername = new TextBox { Location = new Point(140, 66), Width = 200 };

            // Password
            Label lblPass = new Label { Text = "Password:", Location = new Point(40, 110), AutoSize = true };
            txtPassword = new TextBox
            {
                Location = new Point(140, 106),
                Width = 200,
                UseSystemPasswordChar = true
            };

            // Nút Đăng nhập
            btnLogin = new Button
            {
                Text = "Đăng nhập",
                Location = new Point(140, 160),
                Size = new Size(100, 35),
                BackColor = Color.LightGreen,
                FlatStyle = FlatStyle.Popup
            };
            btnLogin.Click += BtnLogin_Click;

            // Nút Thoát
            btnThoat = new Button
            {
                Text = "Thoát",
                Location = new Point(250, 160),
                Size = new Size(90, 35),
                BackColor = Color.LightCoral,
                FlatStyle = FlatStyle.Popup
            };
            btnThoat.Click += (s, e) => this.Close();

            Controls.AddRange(new Control[] { lblTitle, lblUser, txtUsername, lblPass, txtPassword, btnLogin, btnThoat });
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Vui lòng nhập Username!", "Cảnh báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUsername.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Vui lòng nhập Password!", "Cảnh báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }

            // Nếu muốn, có thể kiểm tra user/pass cố định
            if (txtUsername.Text == "admin" && txtPassword.Text == "123")
            {
                MessageBox.Show("Đăng nhập thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Sai Username hoặc Password!", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
