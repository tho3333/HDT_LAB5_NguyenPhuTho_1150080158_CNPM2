﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Nguyenphutho_1150080158_CNPM2
{
    public class ThucHanh2 : Form
    {
        private TextBox txtTenKH;
        private CheckBox chkCaoRang, chkTayTrang, chkHanRang, chkBeRang, chkBocRang;
        private NumericUpDown numHanRang, numBeRang, numBocRang;
        private Button btnTinh, btnThoat;
        private Label lblKetQua;

        public ThucHanh2()
        {
            InitUI();
        }

        private void InitUI()
        {
            Text = "🦷 Phòng khám nha khoa - Thanh toán dịch vụ";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(600, 450);
            BackColor = Color.WhiteSmoke;
            Font = new Font("Segoe UI", 10);

            // Tiêu đề
            Label lblTitle = new Label
            {
                Text = "BẢNG TÍNH TIỀN DỊCH VỤ NHA KHOA",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                AutoSize = true,
                Location = new Point(140, 20)
            };

            // Tên khách hàng
            Label lblTenKH = new Label { Text = "Tên khách hàng:", Location = new Point(40, 70), AutoSize = true };
            txtTenKH = new TextBox { Location = new Point(180, 66), Width = 350, BorderStyle = BorderStyle.FixedSingle };

            // Nhóm dịch vụ
            GroupBox grpDV = new GroupBox
            {
                Text = "Chọn dịch vụ",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                Location = new Point(40, 110),
                Size = new Size(500, 200)
            };

            chkCaoRang = new CheckBox { Text = "Lấy cao răng (50.000đ)", Location = new Point(20, 30), AutoSize = true };
            chkTayTrang = new CheckBox { Text = "Tẩy trắng răng (100.000đ)", Location = new Point(20, 60), AutoSize = true };

            chkHanRang = new CheckBox { Text = "Hàn răng (100.000đ/chiếc)", Location = new Point(20, 90), AutoSize = true };
            numHanRang = new NumericUpDown { Location = new Point(350, 90), Width = 60, Minimum = 0, Maximum = 50 };

            chkBeRang = new CheckBox { Text = "Bẻ răng (10.000đ/chiếc)", Location = new Point(20, 120), AutoSize = true };
            numBeRang = new NumericUpDown { Location = new Point(350, 120), Width = 60, Minimum = 0, Maximum = 50 };

            chkBocRang = new CheckBox { Text = "Bọc răng (1.000.000đ/chiếc)", Location = new Point(20, 150), AutoSize = true };
            numBocRang = new NumericUpDown { Location = new Point(350, 150), Width = 60, Minimum = 0, Maximum = 50 };

            grpDV.Controls.AddRange(new Control[]
            {
                chkCaoRang, chkTayTrang,
                chkHanRang, numHanRang,
                chkBeRang, numBeRang,
                chkBocRang, numBocRang
            });

            // Nút thao tác
            btnTinh = new Button
            {
                Text = "💰 Tính tiền",
                Location = new Point(180, 330),
                Size = new Size(120, 40),
                BackColor = Color.LightGreen,
                FlatStyle = FlatStyle.Popup
            };
            btnTinh.Click += BtnTinh_Click;

            btnThoat = new Button
            {
                Text = "❌ Thoát",
                Location = new Point(330, 330),
                Size = new Size(120, 40),
                BackColor = Color.LightCoral,
                FlatStyle = FlatStyle.Popup
            };
            btnThoat.Click += (s, e) => this.Close();

            // Kết quả
            lblKetQua = new Label
            {
                Text = "Tổng tiền: 0 VND",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.DarkRed,
                AutoSize = true,
                Location = new Point(180, 390)
            };

            Controls.AddRange(new Control[]
            {
                lblTitle, lblTenKH, txtTenKH,
                grpDV, btnTinh, btnThoat, lblKetQua
            });
        }

        private void BtnTinh_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTenKH.Text))
            {
                MessageBox.Show("Tên khách hàng không được để trống!", "Cảnh báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            double tong = 0;
            if (chkCaoRang.Checked) tong += 50000;
            if (chkTayTrang.Checked) tong += 100000;
            if (chkHanRang.Checked) tong += (int)numHanRang.Value * 100000;
            if (chkBeRang.Checked) tong += (int)numBeRang.Value * 10000;
            if (chkBocRang.Checked) tong += (int)numBocRang.Value * 1000000;

            lblKetQua.Text = $"Tổng tiền: {tong:N0} VND";
        }
    }
}
