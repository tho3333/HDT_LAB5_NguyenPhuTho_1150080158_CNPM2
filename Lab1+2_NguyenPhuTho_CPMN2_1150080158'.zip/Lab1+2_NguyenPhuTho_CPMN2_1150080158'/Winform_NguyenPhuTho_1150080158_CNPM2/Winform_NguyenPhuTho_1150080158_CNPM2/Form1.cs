﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Winform_NguyenPhuTho_1150080158_CNPM2
{
    public partial class Form1 : Form

    {
        // Khai báo control ở cấp lớp (field) để các handler “thấy” được
        private TextBox txtA;
        private TextBox txtB;
        private TextBox txtKetQua;
        private Button btnCong, btnTru, btnNhan, btnChia, btnXoa, btnThoat;
        private Label lblA, lblB, lblKq;

        public Form1()
        {
            // Thay cho InitializeComponent của Designer
            InitializeComponentManual();
        }

        private void InitializeComponentManual()
        {
            this.Text = "May tinh 4 phep";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ClientSize = new Size(420, 240);
            this.Font = new Font("Segoe UI", 10);

            // Label A
            lblA = new Label
            {
                AutoSize = true,
                Text = "Nhap a:",
                Location = new Point(20, 20)
            };
            // TextBox A
            txtA = new TextBox
            {
                Name = "txtA",
                Location = new Point(120, 16),
                Width = 260
            };

            // Label B
            lblB = new Label
            {
                AutoSize = true,
                Text = "Nhap b:",
                Location = new Point(20, 60)
            };
            // TextBox B
            txtB = new TextBox
            {
                Name = "txtB",
                Location = new Point(120, 56),
                Width = 260
            };

            // Label KQ
            lblKq = new Label
            {
                AutoSize = true,
                Text = "Ket qua:",
                Location = new Point(20, 100)
            };
            // TextBox KetQua (read-only)
            txtKetQua = new TextBox
            {
                Name = "txtKetQua",
                Location = new Point(120, 96),
                Width = 260,
                ReadOnly = true
            };

            // Buttons
            btnCong = new Button { Name = "btnCong", Text = "Cong", Location = new Point(20, 140), Size = new Size(60, 32) };
            btnTru = new Button { Name = "btnTru", Text = "Tru", Location = new Point(90, 140), Size = new Size(60, 32) };
            btnNhan = new Button { Name = "btnNhan", Text = "Nhan", Location = new Point(160, 140), Size = new Size(60, 32) };
            btnChia = new Button { Name = "btnChia", Text = "Chia", Location = new Point(230, 140), Size = new Size(60, 32) };
            btnXoa = new Button { Name = "btnXoa", Text = "Xoa", Location = new Point(300, 140), Size = new Size(60, 32) };
            btnThoat = new Button { Name = "btnThoat", Text = "Thoat", Location = new Point(300, 180), Size = new Size(60, 32) };

            // Gắn sự kiện
            btnCong.Click += (s, e) => Tinh((a, b) => a + b);
            btnTru.Click += (s, e) => Tinh((a, b) => a - b);
            btnNhan.Click += (s, e) => Tinh((a, b) => a * b);
            btnChia.Click += (s, e) =>
            {
                if (!TryGetAB(out double a, out double b)) return;
                if (b == 0)
                {
                    MessageBox.Show("Khong the chia cho 0!", "Loi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                txtKetQua.Text = (a / b).ToString();
            };
            btnXoa.Click += (s, e) =>
            {
                txtA.Clear();
                txtB.Clear();
                txtKetQua.Clear();
                txtA.Focus();
            };
            btnThoat.Click += (s, e) => this.Close();

            // Thêm control lên form
            this.Controls.AddRange(new Control[]
            {
                lblA, txtA,
                lblB, txtB,
                lblKq, txtKetQua,
                btnCong, btnTru, btnNhan, btnChia, btnXoa, btnThoat
            });
        }

        private bool TryGetAB(out double a, out double b)
        {
            if (!double.TryParse(txtA.Text, out a))
            {
                MessageBox.Show("Vui long nhap so hop le cho a!", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
                b = 0; return false;
            }
            if (!double.TryParse(txtB.Text, out b))
            {
                MessageBox.Show("Vui long nhap so hop le cho b!", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return true;
        }

        private void Tinh(Func<double, double, double> op)
        {
            if (!TryGetAB(out double a, out double b)) return;
            txtKetQua.Text = op(a, b).ToString();
        }
    }
}
